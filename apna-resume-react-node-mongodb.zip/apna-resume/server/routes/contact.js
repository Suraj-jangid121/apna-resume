import express from 'express';
import Contact from '../models/Contact.js';

const router = express.Router();

// POST /api/contact
router.post('/', async (req, res) => {
  try {
    const { firstName, email, message } = req.body;

    if (!firstName || !email || !message) {
      return res.status(400).json({ message: 'firstName, email, and message are required' });
    }

    const submission = await Contact.create(req.body);
    res.status(201).json({ message: 'Message sent successfully', id: submission._id });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

export default router;
