# ApnaResumeBuilder — React + Node.js + MongoDB

Full-stack migration from vanilla HTML/Firebase to **React (Vite) + Express + MongoDB**.

---

## Stack

| Layer     | Tech                                      |
|-----------|-------------------------------------------|
| Frontend  | React 18, Vite, Tailwind CSS, React Router |
| Backend   | Node.js, Express, Mongoose                |
| Database  | MongoDB                                   |
| Auth      | JWT (email/password) + Firebase (Google OAuth only) |

---

## Project Structure

```
apna-resume/
├── server/                  ← Express API
│   ├── index.js             ← Entry point
│   ├── .env.example         ← Copy to .env and fill in
│   ├── models/
│   │   ├── User.js
│   │   ├── Resume.js
│   │   └── Contact.js
│   ├── routes/
│   │   ├── auth.js          ← /api/auth/*
│   │   ├── resumes.js       ← /api/resumes/*
│   │   └── contact.js       ← /api/contact
│   └── middleware/
│       └── auth.js          ← JWT protect middleware
│
└── client/                  ← React app
    ├── src/
    │   ├── main.jsx          ← Router + AuthProvider
    │   ├── firebase.js       ← Google OAuth config
    │   ├── context/
    │   │   └── AuthContext.jsx
    │   ├── components/
    │   │   └── Navbar.jsx
    │   └── pages/
    │       ├── Home.jsx
    │       ├── Login.jsx
    │       ├── Signup.jsx
    │       ├── Profile.jsx
    │       ├── Builder.jsx
    │       └── Contact.jsx
    └── vite.config.js        ← Proxies /api → localhost:5000
```

---

## Setup

### 1. Backend

```bash
cd server
cp .env.example .env
# Edit .env — set MONGODB_URI and JWT_SECRET

npm install
npm run dev     # starts on port 5000
```

### 2. Frontend

```bash
cd client
npm install
npm run dev     # starts on port 5173
```

Vite automatically proxies `/api/*` → `http://localhost:5000`.

---

## API Endpoints

| Method | Path                | Auth | Description          |
|--------|---------------------|------|----------------------|
| POST   | /api/auth/signup    | —    | Register with email  |
| POST   | /api/auth/login     | —    | Login with email     |
| POST   | /api/auth/google    | —    | Google OAuth exchange|
| GET    | /api/auth/me        | JWT  | Get current user     |
| GET    | /api/resumes        | JWT  | List user resumes    |
| POST   | /api/resumes        | JWT  | Create resume        |
| GET    | /api/resumes/:id    | JWT  | Get resume           |
| PUT    | /api/resumes/:id    | JWT  | Update resume        |
| DELETE | /api/resumes/:id    | JWT  | Delete resume        |
| POST   | /api/contact        | —    | Submit contact form  |

---

## Authentication Flow

- **Email/Password**: Handled entirely by Express + bcrypt + JWT. No Firebase needed.
- **Google Sign-In**: Firebase popup → ID token → POST `/api/auth/google` → app JWT issued.
- **JWT**: Stored in `localStorage`, sent as `Authorization: Bearer <token>` on all protected requests.
- **Route Guards**: `<Private>` (redirect to /login) and `<Guest>` (redirect to /) in `main.jsx`.

---

## MongoDB Schemas

### User
`email`, `password` (hashed), `displayName`, `photoURL`, `provider` (email|google), `googleId`

### Resume
All builder fields: `template`, `accentColor`, `fontSize`, `showPhoto/Skills/Projects`, `skills[]`, `experience[]`, `education[]`, `projects[]`, `photo` (base64)

### Contact
`firstName`, `lastName`, `email`, `phone`, `topic`, `message`, `createdAt`

---

## Deployment

**Backend** (Railway / Render / Fly.io):
- Set `MONGODB_URI`, `JWT_SECRET`, `CLIENT_URL` as environment variables
- Run: `node index.js`

**Frontend** (Vercel / Netlify):
- Build: `npm run build`
- Set env var `VITE_API_URL` if backend is on a different domain
- Update `vite.config.js` proxy or use absolute URLs
