import { createContext, useContext, useState, useEffect, useCallback } from "react";
import { signInWithPopup } from "firebase/auth";
import { auth, googleProvider } from "../firebase";

const AuthContext = createContext(null);

const API = "/api/auth";

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(() => localStorage.getItem("arb_token"));
  const [loading, setLoading] = useState(true);

  // Persist token
  const saveToken = (t) => {
    setToken(t);
    if (t) localStorage.setItem("arb_token", t);
    else localStorage.removeItem("arb_token");
  };

  // Fetch current user from /api/auth/me
  const fetchMe = useCallback(async (t) => {
    try {
      const res = await fetch(`${API}/me`, {
        headers: { Authorization: `Bearer ${t}` },
      });
      if (!res.ok) throw new Error("Invalid token");
      const data = await res.json();
      setUser(data.user);
    } catch {
      setUser(null);
      saveToken(null);
    }
  }, []);

  useEffect(() => {
    if (token) {
      fetchMe(token).finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, [token, fetchMe]);

  // Email/password signup
  const signup = async (email, password, displayName) => {
    const res = await fetch(`${API}/signup`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password, displayName }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message);
    saveToken(data.token);
    setUser(data.user);
    return data.user;
  };

  // Email/password login
  const login = async (email, password) => {
    const res = await fetch(`${API}/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message);
    saveToken(data.token);
    setUser(data.user);
    return data.user;
  };

  // Google OAuth via Firebase → exchange with backend
  const googleSignIn = async () => {
    const result = await signInWithPopup(auth, googleProvider);
    const firebaseUser = result.user;

    const res = await fetch(`${API}/google`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        email: firebaseUser.email,
        displayName: firebaseUser.displayName,
        photoURL: firebaseUser.photoURL,
        googleId: firebaseUser.uid,
      }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message);
    saveToken(data.token);
    setUser(data.user);
    return data.user;
  };

  const logout = () => {
    setUser(null);
    saveToken(null);
  };

  // Authenticated fetch helper
  const authFetch = useCallback(
    (url, opts = {}) =>
      fetch(url, {
        ...opts,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
          ...(opts.headers || {}),
        },
      }),
    [token]
  );

  return (
    <AuthContext.Provider
      value={{ user, token, loading, signup, login, googleSignIn, logout, authFetch }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
