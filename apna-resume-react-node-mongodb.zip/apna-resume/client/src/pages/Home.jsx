import { Link } from "react-router-dom";
import Navbar from "../components/Navbar";

const features = [
  { icon: "📄", title: "Choose a recruiter-approved template" },
  { icon: "✍️", title: "Add skills and bullet points in one click" },
  { icon: "⚡", title: "Finish your resume in minutes" },
  { icon: "📥", title: "Download in Word, PDF, and more" },
];

export default function Home() {
  return (
    <div className="min-h-screen bg-black text-white">
      <Navbar />

      {/* Hero */}
      <section className="max-w-7xl mx-auto px-6 pt-32 pb-20 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        <div>
          <div className="inline-flex items-center gap-2 bg-blue-600/10 border border-blue-600/30 rounded-full px-4 py-1.5 text-sm text-blue-400 mb-6">
            <span className="w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
            Free · No credit card required
          </div>

          <h1 className="font-syne text-5xl md:text-6xl font-black leading-[1.1] tracking-tight">
            Free AI Resume
            <br />
            <span className="text-blue-500">Builder.</span> Make
            <br />
            Yours in Minutes
          </h1>

          <p className="mt-6 text-gray-400 text-lg max-w-xl leading-relaxed">
            Easily create a job-winning resume using AI, modern templates,
            and full customization — all in one place.
          </p>

          <div className="flex items-center gap-3 mt-5 text-sm text-gray-500">
            <span className="text-yellow-400 tracking-widest">★★★★★</span>
            <span>18,061 happy users</span>
          </div>

          <div className="flex flex-wrap gap-4 mt-8">
            <Link to="/signup"
              className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-8 py-3.5 rounded-full transition-colors shadow-lg shadow-blue-600/20">
              Join Us Now
            </Link>
            <Link to="/builder"
              className="border border-white/20 hover:border-white/50 px-8 py-3.5 rounded-full transition-colors">
              Build your Resume
            </Link>
          </div>
        </div>

        {/* Visual card placeholder */}
        <div className="flex justify-center">
          <div className="relative w-full max-w-sm">
            <div className="absolute -inset-4 bg-blue-600/10 rounded-3xl blur-2xl" />
            <div className="relative bg-[#101010] border border-[#1f1f1f] rounded-3xl p-8 shadow-2xl">
              <div className="h-4 w-3/4 bg-blue-600/30 rounded mb-3" />
              <div className="h-3 w-1/2 bg-gray-700 rounded mb-6" />
              <div className="space-y-2">
                {[100, 90, 80, 70, 85].map((w, i) => (
                  <div key={i} className="h-2.5 bg-gray-800 rounded" style={{ width: `${w}%` }} />
                ))}
              </div>
              <div className="mt-6 grid grid-cols-2 gap-3">
                <div className="h-16 bg-gray-800/50 rounded-xl" />
                <div className="h-16 bg-blue-600/10 border border-blue-600/20 rounded-xl" />
              </div>
              <div className="mt-4 space-y-2">
                {[70, 60].map((w, i) => (
                  <div key={i} className="h-2 bg-gray-800 rounded" style={{ width: `${w}%` }} />
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="max-w-7xl mx-auto px-6 py-24">
        <h2 className="font-syne text-4xl font-black text-center mb-4">
          Make a Resume That Gets Results
        </h2>
        <p className="text-center text-gray-500 mb-16 max-w-xl mx-auto">
          Everything you need to build, customize, and export a professional resume — fast.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((f, i) => (
            <div key={i}
              className="bg-[#101010] border border-[#1f1f1f] hover:border-blue-900/50 rounded-2xl p-6 transition-colors group">
              <div className="text-4xl mb-4 group-hover:scale-110 transition-transform inline-block">{f.icon}</div>
              <h3 className="font-semibold text-lg leading-snug">{f.title}</h3>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <Link to="/builder"
            className="inline-block bg-blue-600 hover:bg-blue-700 text-white font-bold px-10 py-4 rounded-full shadow-lg shadow-blue-600/20 transition-colors">
            Create my resume →
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-[#1a1a1a] py-8 text-center text-gray-600 text-sm">
        © {new Date().getFullYear()} ApnaResumeBuilder · Built with React + Node.js + MongoDB
      </footer>
    </div>
  );
}
