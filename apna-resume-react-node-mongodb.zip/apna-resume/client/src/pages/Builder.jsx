import { useState, useEffect, useRef, useCallback } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

// ─── Initial State ───────────────────────────────────────────────────────────
const BLANK = {
  title: "My Resume",
  name: "", role: "", email: "", phone: "", location: "",
  linkedin: "", website: "", summary: "", photo: "",
  template: "modern", accentColor: "#2563eb", fontSize: 13,
  showPhoto: true, showSkills: true, showProjects: true,
  skills: [],
  experience: [{ title: "", company: "", period: "", desc: "" }],
  education: [{ degree: "", school: "", year: "", grade: "" }],
  projects: [{ name: "", tech: "", desc: "", link: "" }],
};

// ─── Helpers ──────────────────────────────────────────────────────────────────
const esc = (s) => (s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

const TEMPLATES = ["modern", "classic", "minimal", "bold"];
const COLORS = ["#2563eb", "#dc2626", "#16a34a", "#7c3aed", "#d97706", "#0891b2", "#111827"];

// ─── Resume HTML generator (mirrors original builder.html logic) ──────────────
function buildHTML(D) {
  const c = D.accentColor;
  const fs = D.fontSize;

  const sh = (t) => `<div style="font-size:9px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:${c};border-left:3px solid ${c};padding-left:8px;margin:14px 0 7px;">${esc(t)}</div>`;
  const shL = (t) => `<div style="font-size:9px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:${c};border-bottom:1px solid ${c}22;padding-bottom:4px;margin:14px 0 7px;">${esc(t)}</div>`;

  const contactParts = [D.email, D.phone, D.location, D.linkedin, D.website].filter(Boolean).map(esc);

  const summaryBlock = D.summary
    ? `<p style="font-size:${fs - 1}px;color:#555;line-height:1.6;margin:0;">${esc(D.summary)}</p>` : "";

  const skillsBlock = D.skills.length
    ? `<div style="display:flex;flex-wrap:wrap;gap:4px;">${D.skills.map(s =>
        `<span style="background:${c}18;color:${c};font-size:${fs - 2}px;padding:2px 8px;border-radius:20px;border:1px solid ${c}33;">${esc(s)}</span>`
      ).join("")}</div>` : "";

  const expBlock = D.experience.map(e =>
    `<div style="margin-bottom:10px;">
      <div style="display:flex;justify-content:space-between;align-items:baseline;">
        <strong style="font-size:${fs}px;color:#111;">${esc(e.title)}</strong>
        <span style="font-size:${fs - 2}px;color:#888;">${esc(e.period)}</span>
      </div>
      <div style="font-size:${fs - 1}px;color:${c};font-weight:600;">${esc(e.company)}</div>
      <p style="font-size:${fs - 1}px;color:#555;margin:3px 0 0;line-height:1.5;">${esc(e.desc)}</p>
    </div>`
  ).join("");

  const eduBlock = D.education.map(e =>
    `<div style="margin-bottom:10px;">
      <strong style="font-size:${fs}px;color:#111;display:block;">${esc(e.degree)}</strong>
      <div style="font-size:${fs - 1}px;color:${c};font-weight:600;">${esc(e.school)}${e.year ? ` · ${esc(e.year)}` : ""}${e.grade ? ` · ${esc(e.grade)}` : ""}</div>
    </div>`
  ).join("");

  const projBlock = D.showProjects && D.projects.length
    ? D.projects.map(p =>
        `<div style="margin-bottom:10px;">
          <div style="display:flex;justify-content:space-between;">
            <strong style="font-size:${fs}px;color:#111;">${esc(p.name)}</strong>
            <span style="font-size:${fs - 2}px;color:${c};">${esc(p.tech)}</span>
          </div>
          <p style="font-size:${fs - 1}px;color:#555;margin:2px 0 0;line-height:1.45;">${esc(p.desc)}</p>
          ${p.link ? `<div style="font-size:${fs - 2}px;color:${c};margin-top:2px;">${esc(p.link)}</div>` : ""}
        </div>`
      ).join("") : "";

  const photoEl = D.showPhoto && D.photo
    ? `<img src="${D.photo}" style="width:78px;height:78px;border-radius:50%;object-fit:cover;border:3px solid ${c};float:right;margin:0 0 10px 16px;"/>`
    : "";

  if (D.template === "modern") {
    return `<div style="display:grid;grid-template-columns:168px 1fr;min-height:297mm;font-family:'DM Sans',sans-serif;">
      <div style="background:${c}0c;padding:22px 14px;border-right:2px solid ${c}22;">
        ${D.showPhoto && D.photo ? `<img src="${D.photo}" style="width:96px;height:96px;border-radius:50%;object-fit:cover;border:3px solid ${c};display:block;margin:0 auto 16px;"/>` : ""}
        ${shL("Contact")}
        <div style="font-size:${fs - 2}px;color:#555;line-height:2.1;">
          ${D.email ? `<div>✉ ${esc(D.email)}</div>` : ""}
          ${D.phone ? `<div>📞 ${esc(D.phone)}</div>` : ""}
          ${D.location ? `<div>📍 ${esc(D.location)}</div>` : ""}
          ${D.linkedin ? `<div>in ${esc(D.linkedin)}</div>` : ""}
          ${D.website ? `<div>🌐 ${esc(D.website)}</div>` : ""}
        </div>
        ${D.showSkills && D.skills.length ? shL("Skills") + skillsBlock : ""}
      </div>
      <div style="padding:22px;">
        <div style="border-bottom:3px solid ${c};padding-bottom:12px;margin-bottom:4px;">
          <h1 style="font-size:26px;font-weight:800;color:${c};margin:0;font-family:'Syne',sans-serif;">${esc(D.name)}</h1>
          <p style="font-size:${fs + 1}px;font-weight:500;color:#666;margin:3px 0 0;">${esc(D.role)}</p>
        </div>
        ${summaryBlock ? sh("About") + summaryBlock : ""}
        ${D.experience.length ? sh("Experience") + expBlock : ""}
        ${D.education.length ? sh("Education") + eduBlock : ""}
        ${D.showProjects && D.projects.length ? sh("Projects") + projBlock : ""}
      </div>
    </div>`;
  }

  if (D.template === "classic") {
    return `<div style="padding:28px;min-height:297mm;font-family:'DM Sans',sans-serif;">
      <div style="overflow:hidden;border-bottom:3px solid ${c};padding-bottom:16px;margin-bottom:4px;">
        ${photoEl}
        <h1 style="font-size:28px;font-weight:800;color:#111;margin:0;font-family:'Syne',sans-serif;">${esc(D.name)}</h1>
        <p style="font-size:${fs + 1}px;font-weight:600;color:${c};margin:5px 0 8px;">${esc(D.role)}</p>
        <div style="font-size:${fs - 2}px;color:#666;line-height:1.9;">${contactParts.join(" &nbsp;·&nbsp; ")}</div>
      </div>
      ${summaryBlock ? sh("Summary") + summaryBlock : ""}
      ${D.showSkills && D.skills.length ? sh("Skills") + skillsBlock : ""}
      ${D.experience.length ? sh("Work Experience") + expBlock : ""}
      ${D.education.length ? sh("Education") + eduBlock : ""}
      ${D.showProjects && D.projects.length ? sh("Projects") + projBlock : ""}
    </div>`;
  }

  if (D.template === "minimal") {
    return `<div style="padding:28px;min-height:297mm;font-family:'DM Sans',sans-serif;">
      <div style="text-align:center;padding-bottom:18px;border-bottom:1px solid #e5e5e5;margin-bottom:4px;">
        ${D.showPhoto && D.photo ? `<img src="${D.photo}" style="width:84px;height:84px;border-radius:50%;object-fit:cover;border:3px solid ${c};display:block;margin:0 auto 12px;"/>` : ""}
        <h1 style="font-size:30px;font-weight:800;color:#111;margin:0;font-family:'Syne',sans-serif;">${esc(D.name)}</h1>
        <p style="font-size:${fs + 1}px;color:${c};font-weight:600;margin:5px 0 10px;">${esc(D.role)}</p>
        <div style="font-size:${fs - 2}px;color:#888;line-height:2;">${contactParts.join(" &nbsp;·&nbsp; ")}</div>
      </div>
      ${summaryBlock ? `<div style="margin:14px 0;">${summaryBlock}</div>` : ""}
      ${D.showSkills && D.skills.length ? sh("Skills") + skillsBlock : ""}
      ${D.experience.length ? sh("Experience") + expBlock : ""}
      ${D.education.length ? sh("Education") + eduBlock : ""}
      ${D.showProjects && D.projects.length ? sh("Projects") + projBlock : ""}
    </div>`;
  }

  // bold
  return `<div style="min-height:297mm;font-family:'DM Sans',sans-serif;">
    <div style="background:${c};padding:24px 28px;display:flex;align-items:center;gap:20px;">
      ${D.showPhoto && D.photo ? `<img src="${D.photo}" style="width:84px;height:84px;border-radius:50%;object-fit:cover;border:3px solid rgba(255,255,255,0.6);flex-shrink:0;"/>` : ""}
      <div>
        <h1 style="font-size:28px;font-weight:800;color:#fff;margin:0;font-family:'Syne',sans-serif;">${esc(D.name)}</h1>
        <p style="font-size:${fs + 2}px;color:rgba(255,255,255,0.8);margin:5px 0 0;">${esc(D.role)}</p>
      </div>
    </div>
    <div style="display:flex;flex-wrap:wrap;gap:7px;padding:14px 28px;border-bottom:2px solid ${c}22;">
      ${contactParts.map(p => `<span style="font-size:${fs - 2}px;background:${c}18;color:${c};padding:3px 10px;border-radius:20px;">${p}</span>`).join("")}
    </div>
    <div style="padding:6px 28px 28px;">
      ${summaryBlock ? sh("About Me") + summaryBlock : ""}
      ${D.showSkills && D.skills.length ? sh("Skills") + skillsBlock : ""}
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:24px;">
        <div>${D.experience.length ? sh("Experience") + expBlock : ""}</div>
        <div>${D.education.length ? sh("Education") + eduBlock : ""}${D.showProjects && D.projects.length ? sh("Projects") + projBlock : ""}</div>
      </div>
    </div>
  </div>`;
}

// ─── Field component ──────────────────────────────────────────────────────────
const Field = ({ label, children }) => (
  <div className="mb-2.5">
    {label && <label className="block text-[10px] font-bold uppercase tracking-widest text-gray-600 mb-1">{label}</label>}
    {children}
  </div>
);

const Input = ({ value, onChange, placeholder, type = "text", className = "" }) => (
  <input
    type={type}
    value={value || ""}
    onChange={e => onChange(e.target.value)}
    placeholder={placeholder}
    className={`w-full bg-[#161616] border border-[#2a2a2a] focus:border-blue-600 text-[#f0f0f0] px-2.5 py-2 rounded-md text-xs outline-none transition-colors placeholder:text-[#333] ${className}`}
  />
);

const Textarea = ({ value, onChange, placeholder }) => (
  <textarea
    value={value || ""}
    onChange={e => onChange(e.target.value)}
    placeholder={placeholder}
    rows={3}
    className="w-full bg-[#161616] border border-[#2a2a2a] focus:border-blue-600 text-[#f0f0f0] px-2.5 py-2 rounded-md text-xs outline-none transition-colors resize-y placeholder:text-[#333]"
  />
);

// ─── Main Component ───────────────────────────────────────────────────────────
export default function Builder() {
  const { id } = useParams();
  const { user, authFetch } = useAuth();
  const navigate = useNavigate();

  const [D, setD] = useState(BLANK);
  const [tab, setTab] = useState("basics");
  const [skillInput, setSkillInput] = useState("");
  const [zoom, setZoom] = useState(65);
  const [saving, setSaving] = useState(false);
  const [saveMsg, setSaveMsg] = useState("");
  const [resumeId, setResumeId] = useState(id || null);
  const previewRef = useRef(null);

  // Load resume if editing existing
  useEffect(() => {
    if (id && user) {
      authFetch(`/api/resumes/${id}`)
        .then(r => r.json())
        .then(data => { if (data._id) setD(data); })
        .catch(() => {});
    }
  }, [id, user, authFetch]);

  const upd = (field, value) => setD(d => ({ ...d, [field]: value }));

  // Array helpers
  const addItem = (field, blank) => setD(d => ({ ...d, [field]: [...d[field], blank] }));
  const delItem = (field, idx) => setD(d => ({ ...d, [field]: d[field].filter((_, i) => i !== idx) }));
  const updItem = (field, idx, key, val) =>
    setD(d => ({
      ...d,
      [field]: d[field].map((it, i) => i === idx ? { ...it, [key]: val } : it),
    }));

  // Skills
  const addSkill = () => {
    const s = skillInput.trim();
    if (s && !D.skills.includes(s)) {
      setD(d => ({ ...d, skills: [...d.skills, s] }));
    }
    setSkillInput("");
  };
  const delSkill = (s) => setD(d => ({ ...d, skills: d.skills.filter(x => x !== s) }));

  // Photo upload
  const handlePhoto = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => upd("photo", ev.target.result);
    reader.readAsDataURL(file);
  };

  // Save to MongoDB
  const saveResume = async () => {
    if (!user) {
      navigate("/login");
      return;
    }
    setSaving(true);
    try {
      const method = resumeId ? "PUT" : "POST";
      const url = resumeId ? `/api/resumes/${resumeId}` : "/api/resumes";
      const res = await authFetch(url, { method, body: JSON.stringify(D) });
      const data = await res.json();
      if (data._id) {
        setResumeId(data._id);
        if (!id) navigate(`/builder/${data._id}`, { replace: true });
        setSaveMsg("✓ Saved");
        setTimeout(() => setSaveMsg(""), 3000);
      }
    } catch {
      setSaveMsg("Save failed");
    } finally {
      setSaving(false);
    }
  };

  // Print / PDF
  const handlePrint = () => {
    const html = buildHTML(D);
    const win = window.open("", "_blank");
    win.document.write(`<!DOCTYPE html><html><head>
      <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Syne:wght@700;800&display=swap" rel="stylesheet"/>
      <style>*{margin:0;padding:0;box-sizing:border-box;}body{background:#fff;}@media print{body{margin:0;}}</style>
      </head><body>${html}</body></html>`);
    win.document.close();
    setTimeout(() => { win.focus(); win.print(); }, 600);
  };

  const preview = buildHTML(D);
  const scale = zoom / 100;

  const TABS = [
    { id: "basics", label: "👤", name: "Basics" },
    { id: "experience", label: "💼", name: "Work" },
    { id: "education", label: "🎓", name: "Edu" },
    { id: "skills", label: "⚡", name: "Skills" },
    { id: "projects", label: "🚀", name: "Projects" },
    { id: "design", label: "🎨", name: "Design" },
  ];

  return (
    <div className="flex flex-col h-screen bg-[#080808] text-[#f0f0f0] overflow-hidden">
      {/* Top bar */}
      <div className="h-13 bg-[#101010] border-b border-[#1f1f1f] flex items-center justify-between px-5 shrink-0 z-50">
        <div className="flex items-center gap-3">
          <Link to="/" className="flex items-center gap-2">
            <span className="bg-blue-600 text-white text-xs font-black px-2 py-1 rounded-md font-syne">ARB</span>
            <span className="text-sm font-semibold font-syne hidden sm:block">ApnaResumeBuilder</span>
          </Link>
          <span className="text-[#333] hidden sm:block">·</span>
          <input
            value={D.title}
            onChange={e => upd("title", e.target.value)}
            className="bg-transparent text-sm text-gray-400 outline-none border-b border-transparent focus:border-blue-600 px-1 w-32 hidden sm:block"
          />
        </div>

        <div className="flex items-center gap-2">
          {saveMsg && <span className="text-xs text-green-400 font-semibold">{saveMsg}</span>}
          <button onClick={saveResume} disabled={saving}
            className="text-xs font-semibold px-3 py-1.5 rounded-md bg-blue-600 hover:bg-blue-700 disabled:opacity-60 transition-colors flex items-center gap-1.5">
            {saving ? "Saving…" : (user ? "💾 Save" : "🔐 Save")}
          </button>
          <button onClick={handlePrint}
            className="text-xs font-semibold px-3 py-1.5 rounded-md border border-[#2a2a2a] hover:bg-[#161616] transition-colors">
            📥 PDF
          </button>
          <Link to="/" className="text-xs text-gray-600 hover:text-gray-400 px-2 py-1.5 rounded-md hover:bg-[#161616]">
            ✕
          </Link>
        </div>
      </div>

      {/* Main layout */}
      <div className="flex flex-1 overflow-hidden">

        {/* Sidebar */}
        <div className="w-[300px] min-w-[300px] bg-[#101010] border-r border-[#1f1f1f] flex flex-col overflow-hidden">
          {/* Tabs */}
          <div className="flex border-b border-[#1f1f1f] bg-[#080808] shrink-0">
            {TABS.map(t => (
              <button key={t.id} onClick={() => setTab(t.id)}
                className={`flex-1 py-2.5 text-base transition-all border-b-2 ${
                  tab === t.id ? "text-blue-500 border-blue-600 bg-[#101010]" : "text-[#444] border-transparent hover:text-[#888]"
                }`}>
                {t.label}
                <span className="block text-[8px] font-bold uppercase tracking-widest mt-0.5" style={{ color: "inherit" }}>{t.name}</span>
              </button>
            ))}
          </div>

          {/* Tab body */}
          <div className="flex-1 overflow-y-auto p-4 space-y-1 text-xs">

            {/* ── BASICS ── */}
            {tab === "basics" && (
              <div>
                {/* Photo */}
                <div className="flex items-center gap-3 mb-4">
                  <label className="w-14 h-14 rounded-full bg-[#161616] border-2 border-dashed border-[#2a2a2a] flex items-center justify-center cursor-pointer overflow-hidden hover:border-blue-600 transition-colors shrink-0">
                    {D.photo
                      ? <img src={D.photo} className="w-full h-full object-cover" alt="photo" />
                      : <span className="text-xl">📷</span>}
                    <input type="file" accept="image/*" className="hidden" onChange={handlePhoto} />
                  </label>
                  <div className="text-xs text-gray-600">
                    <p className="font-semibold text-gray-500">Profile Photo</p>
                    <p>Click to upload</p>
                    {D.photo && <button onClick={() => upd("photo", "")} className="text-red-400 hover:text-red-300 mt-0.5">Remove</button>}
                  </div>
                </div>

                <Field label="Full Name"><Input value={D.name} onChange={v => upd("name", v)} placeholder="Rahul Sharma" /></Field>
                <Field label="Job Title"><Input value={D.role} onChange={v => upd("role", v)} placeholder="Software Engineer" /></Field>
                <Field label="Email"><Input value={D.email} onChange={v => upd("email", v)} placeholder="rahul@email.com" type="email" /></Field>
                <Field label="Phone"><Input value={D.phone} onChange={v => upd("phone", v)} placeholder="+91 9876543210" /></Field>
                <Field label="Location"><Input value={D.location} onChange={v => upd("location", v)} placeholder="Jaipur, Rajasthan" /></Field>
                <Field label="LinkedIn"><Input value={D.linkedin} onChange={v => upd("linkedin", v)} placeholder="linkedin.com/in/rahul" /></Field>
                <Field label="Website"><Input value={D.website} onChange={v => upd("website", v)} placeholder="rahul.dev" /></Field>
                <Field label="Summary"><Textarea value={D.summary} onChange={v => upd("summary", v)} placeholder="Brief professional summary…" /></Field>
              </div>
            )}

            {/* ── EXPERIENCE ── */}
            {tab === "experience" && (
              <div>
                <div className="flex justify-between items-center mb-3">
                  <span className="text-[9px] font-bold uppercase tracking-widest text-blue-500 border-l-2 border-blue-600 pl-2">Work Experience</span>
                </div>
                {D.experience.map((e, i) => (
                  <div key={i} className="bg-[#161616] border border-[#2a2a2a] rounded-lg p-3 mb-2 relative group">
                    <button onClick={() => delItem("experience", i)}
                      className="absolute top-2 right-2 text-[#444] hover:text-red-400 text-xs opacity-0 group-hover:opacity-100 transition-all">✕</button>
                    <Field label="Job Title"><Input value={e.title} onChange={v => updItem("experience", i, "title", v)} placeholder="Software Engineer" /></Field>
                    <Field label="Company"><Input value={e.company} onChange={v => updItem("experience", i, "company", v)} placeholder="Google" /></Field>
                    <Field label="Period"><Input value={e.period} onChange={v => updItem("experience", i, "period", v)} placeholder="Jan 2022 – Present" /></Field>
                    <Field label="Description"><Textarea value={e.desc} onChange={v => updItem("experience", i, "desc", v)} placeholder="Key responsibilities and achievements…" /></Field>
                  </div>
                ))}
                <button onClick={() => addItem("experience", { title: "", company: "", period: "", desc: "" })}
                  className="w-full py-2 border border-dashed border-[#2a2a2a] hover:border-blue-600 hover:text-blue-500 rounded-lg text-[#444] transition-all text-xs">
                  + Add Experience
                </button>
              </div>
            )}

            {/* ── EDUCATION ── */}
            {tab === "education" && (
              <div>
                <div className="flex justify-between items-center mb-3">
                  <span className="text-[9px] font-bold uppercase tracking-widest text-blue-500 border-l-2 border-blue-600 pl-2">Education</span>
                </div>
                {D.education.map((e, i) => (
                  <div key={i} className="bg-[#161616] border border-[#2a2a2a] rounded-lg p-3 mb-2 relative group">
                    <button onClick={() => delItem("education", i)}
                      className="absolute top-2 right-2 text-[#444] hover:text-red-400 text-xs opacity-0 group-hover:opacity-100 transition-all">✕</button>
                    <Field label="Degree / Course"><Input value={e.degree} onChange={v => updItem("education", i, "degree", v)} placeholder="B.Tech Computer Science" /></Field>
                    <Field label="Institution"><Input value={e.school} onChange={v => updItem("education", i, "school", v)} placeholder="IIT Bombay" /></Field>
                    <div className="grid grid-cols-2 gap-2">
                      <Field label="Year"><Input value={e.year} onChange={v => updItem("education", i, "year", v)} placeholder="2024" /></Field>
                      <Field label="Grade / CGPA"><Input value={e.grade} onChange={v => updItem("education", i, "grade", v)} placeholder="9.2" /></Field>
                    </div>
                  </div>
                ))}
                <button onClick={() => addItem("education", { degree: "", school: "", year: "", grade: "" })}
                  className="w-full py-2 border border-dashed border-[#2a2a2a] hover:border-blue-600 hover:text-blue-500 rounded-lg text-[#444] transition-all text-xs">
                  + Add Education
                </button>
              </div>
            )}

            {/* ── SKILLS ── */}
            {tab === "skills" && (
              <div>
                <div className="mb-3">
                  <span className="text-[9px] font-bold uppercase tracking-widest text-blue-500 border-l-2 border-blue-600 pl-2">Skills</span>
                </div>
                <div className="flex gap-2 mb-3">
                  <input
                    value={skillInput}
                    onChange={e => setSkillInput(e.target.value)}
                    onKeyDown={e => e.key === "Enter" && addSkill()}
                    placeholder="Type a skill & press Enter"
                    className="flex-1 bg-[#161616] border border-[#2a2a2a] focus:border-blue-600 text-[#f0f0f0] px-2.5 py-2 rounded-md text-xs outline-none transition-colors placeholder:text-[#333]"
                  />
                  <button onClick={addSkill}
                    className="px-3 py-2 bg-blue-600 hover:bg-blue-700 rounded-md text-xs font-semibold transition-colors">
                    Add
                  </button>
                </div>
                <div className="flex flex-wrap gap-1.5 min-h-[32px]">
                  {D.skills.map(s => (
                    <span key={s} className="flex items-center gap-1 bg-blue-600/15 border border-blue-600/30 text-blue-300 px-2.5 py-1 rounded-full text-xs">
                      {s}
                      <button onClick={() => delSkill(s)} className="text-[10px] text-[#444] hover:text-red-400 transition-colors">✕</button>
                    </span>
                  ))}
                </div>
                {D.skills.length === 0 && (
                  <p className="text-[#333] text-xs mt-2">No skills added yet.</p>
                )}
              </div>
            )}

            {/* ── PROJECTS ── */}
            {tab === "projects" && (
              <div>
                <div className="flex justify-between items-center mb-3">
                  <span className="text-[9px] font-bold uppercase tracking-widest text-blue-500 border-l-2 border-blue-600 pl-2">Projects</span>
                </div>
                {D.projects.map((p, i) => (
                  <div key={i} className="bg-[#161616] border border-[#2a2a2a] rounded-lg p-3 mb-2 relative group">
                    <button onClick={() => delItem("projects", i)}
                      className="absolute top-2 right-2 text-[#444] hover:text-red-400 text-xs opacity-0 group-hover:opacity-100 transition-all">✕</button>
                    <Field label="Project Name"><Input value={p.name} onChange={v => updItem("projects", i, "name", v)} placeholder="Portfolio Website" /></Field>
                    <Field label="Tech Stack"><Input value={p.tech} onChange={v => updItem("projects", i, "tech", v)} placeholder="React, Node.js, MongoDB" /></Field>
                    <Field label="Description"><Textarea value={p.desc} onChange={v => updItem("projects", i, "desc", v)} placeholder="What you built and why…" /></Field>
                    <Field label="Link"><Input value={p.link} onChange={v => updItem("projects", i, "link", v)} placeholder="github.com/rahul/project" /></Field>
                  </div>
                ))}
                <button onClick={() => addItem("projects", { name: "", tech: "", desc: "", link: "" })}
                  className="w-full py-2 border border-dashed border-[#2a2a2a] hover:border-blue-600 hover:text-blue-500 rounded-lg text-[#444] transition-all text-xs">
                  + Add Project
                </button>
              </div>
            )}

            {/* ── DESIGN ── */}
            {tab === "design" && (
              <div className="space-y-4">
                <div>
                  <span className="text-[9px] font-bold uppercase tracking-widest text-blue-500 border-l-2 border-blue-600 pl-2 block mb-3">Template</span>
                  <div className="grid grid-cols-2 gap-2">
                    {TEMPLATES.map(t => (
                      <button key={t} onClick={() => upd("template", t)}
                        className={`py-2 rounded-lg text-xs font-semibold capitalize border transition-all ${
                          D.template === t ? "bg-blue-600 border-blue-600 text-white" : "border-[#2a2a2a] text-gray-500 hover:border-blue-900"
                        }`}>
                        {t}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <span className="text-[9px] font-bold uppercase tracking-widest text-blue-500 border-l-2 border-blue-600 pl-2 block mb-3">Accent Color</span>
                  <div className="flex flex-wrap gap-2">
                    {COLORS.map(color => (
                      <button key={color} onClick={() => upd("accentColor", color)}
                        className={`w-7 h-7 rounded-full transition-all ${D.accentColor === color ? "ring-2 ring-white ring-offset-2 ring-offset-[#101010] scale-110" : "hover:scale-105"}`}
                        style={{ background: color }}
                      />
                    ))}
                    <label className="w-7 h-7 rounded-full border-2 border-dashed border-[#2a2a2a] flex items-center justify-center cursor-pointer hover:border-gray-500 text-xs">
                      +
                      <input type="color" value={D.accentColor} onChange={e => upd("accentColor", e.target.value)} className="opacity-0 w-0 h-0 absolute" />
                    </label>
                  </div>
                </div>

                <div>
                  <span className="text-[9px] font-bold uppercase tracking-widest text-blue-500 border-l-2 border-blue-600 pl-2 block mb-3">Font Size: {D.fontSize}px</span>
                  <input type="range" min={10} max={16} value={D.fontSize} onChange={e => upd("fontSize", +e.target.value)}
                    className="w-full accent-blue-600" />
                </div>

                <div>
                  <span className="text-[9px] font-bold uppercase tracking-widest text-blue-500 border-l-2 border-blue-600 pl-2 block mb-3">Sections</span>
                  {[
                    { key: "showPhoto", label: "Show Photo" },
                    { key: "showSkills", label: "Show Skills" },
                    { key: "showProjects", label: "Show Projects" },
                  ].map(({ key, label }) => (
                    <label key={key} className="flex items-center gap-2 cursor-pointer mb-2">
                      <div onClick={() => upd(key, !D[key])}
                        className={`w-9 h-5 rounded-full transition-colors relative ${D[key] ? "bg-blue-600" : "bg-[#2a2a2a]"}`}>
                        <div className={`absolute top-0.5 w-4 h-4 bg-white rounded-full transition-transform ${D[key] ? "translate-x-4" : "translate-x-0.5"}`} />
                      </div>
                      <span className="text-xs text-gray-500">{label}</span>
                    </label>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Preview pane */}
        <div className="flex-1 flex flex-col overflow-hidden bg-[#0a0a0a]" ref={previewRef}>
          {/* Zoom bar */}
          <div className="h-10 bg-[#0d0d0d] border-b border-[#1a1a1a] flex items-center justify-center gap-3 shrink-0 px-4">
            <button onClick={() => setZoom(z => Math.max(25, z - 10))}
              className="w-7 h-7 flex items-center justify-center rounded border border-[#2a2a2a] hover:bg-[#161616] text-xs transition-colors">−</button>
            {[40, 65, 80, 100].map(z => (
              <button key={z} onClick={() => setZoom(z)}
                className={`text-xs px-2 py-1 rounded transition-colors ${zoom === z ? "bg-blue-600 text-white" : "text-gray-600 hover:text-gray-400"}`}>
                {z}%
              </button>
            ))}
            <button onClick={() => setZoom(z => Math.min(150, z + 10))}
              className="w-7 h-7 flex items-center justify-center rounded border border-[#2a2a2a] hover:bg-[#161616] text-xs transition-colors">+</button>
            <span className="text-xs text-gray-600 ml-1 w-10 text-center">{zoom}%</span>
          </div>

          {/* Paper */}
          <div className="flex-1 overflow-auto flex justify-center py-6 px-4">
            <div
              style={{
                width: 794,
                minHeight: 1123,
                background: "#fff",
                transform: `scale(${scale})`,
                transformOrigin: "top center",
                marginBottom: `${(1123 * scale) - 1123}px`,
                boxShadow: "0 4px 40px rgba(0,0,0,0.5)",
                borderRadius: 2,
                flexShrink: 0,
              }}
              dangerouslySetInnerHTML={{ __html: preview }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
