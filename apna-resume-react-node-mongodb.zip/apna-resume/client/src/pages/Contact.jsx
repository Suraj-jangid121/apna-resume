import { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import Navbar from "../components/Navbar";

const TOPIC_KEYWORDS = {
  "Account & Billing": ["payment", "billing", "invoice", "subscription", "charge", "refund", "plan", "price", "paid", "cancel"],
  "Resume Templates": ["template", "design", "layout", "color", "font", "style", "format", "theme"],
  "Technical Issue": ["error", "bug", "broken", "crash", "not working", "issue", "problem", "fix", "fail", "slow"],
  "Feature Request": ["feature", "add", "suggestion", "improve", "want", "wish", "would be nice", "request"],
};

const FAQS = [
  { q: "How do I cancel my subscription?", a: "You can cancel anytime from Account Settings. No cancellation fees apply — access continues until end of billing period." },
  { q: "Can I download my resume as PDF?", a: "Yes! PDF download is free. Word (.docx) export is available on Pro plans." },
  { q: "Is ApnaResumeBuilder really free?", a: "Yes, the basic plan is completely free. Build and download your resume without paying anything. Pro plans unlock extra templates and features." },
  { q: "How does AI writing help work?", a: "AI suggests professional bullet points based on your job title and experience, helping you write descriptions that stand out to recruiters." },
];

function suggestTopic(msg) {
  const lower = msg.toLowerCase();
  for (const [topic, keywords] of Object.entries(TOPIC_KEYWORDS)) {
    if (keywords.some(k => lower.includes(k))) return topic;
  }
  return null;
}

export default function Contact() {
  const [form, setForm] = useState({ firstName: "", lastName: "", email: "", phone: "", topic: "", message: "" });
  const [charCount, setCharCount] = useState(0);
  const [topicSuggestion, setTopicSuggestion] = useState("");
  const [emailValid, setEmailValid] = useState(null);
  const [draftMsg, setDraftMsg] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);
  const [loading, setLoading] = useState(false);
  const [openFaq, setOpenFaq] = useState(null);
  const draftTimer = useRef(null);

  // Restore draft
  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem("arb_contact_draft") || "{}");
      if (saved.firstName || saved.email || saved.message) {
        setForm(f => ({ ...f, ...saved }));
        setCharCount((saved.message || "").length);
        setDraftMsg("📋 Draft restored from your last visit");
      }
    } catch { /* ignore */ }
  }, []);

  const set = (field, value) => setForm(f => ({ ...f, [field]: value }));

  const handleMessage = (val) => {
    set("message", val);
    setCharCount(val.length);
    const suggested = suggestTopic(val);
    if (suggested && !form.topic) {
      setTopicSuggestion(suggested);
    } else if (!suggested && !form.topic) {
      setTopicSuggestion("");
    }
    scheduleDraft({ ...form, message: val });
  };

  const handleEmail = (val) => {
    set("email", val);
    const valid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val);
    setEmailValid(val ? valid : null);
  };

  const scheduleDraft = (data) => {
    clearTimeout(draftTimer.current);
    draftTimer.current = setTimeout(() => {
      localStorage.setItem("arb_contact_draft", JSON.stringify(data));
      setDraftMsg("💾 Draft saved");
      setTimeout(() => setDraftMsg(""), 2000);
    }, 2000);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    if (!form.firstName || form.firstName.length < 2) return setError("First name is required.");
    if (!emailValid) return setError("A valid email address is required.");
    if (!form.message) return setError("Message cannot be empty.");

    setLoading(true);
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.message);
      }
      localStorage.removeItem("arb_contact_draft");
      setSuccess(true);
    } catch (err) {
      setError(err.message || "Failed to send. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setForm({ firstName: "", lastName: "", email: "", phone: "", topic: "", message: "" });
    setSuccess(false);
    setError("");
    setCharCount(0);
    setEmailValid(null);
    setTopicSuggestion("");
    setDraftMsg("");
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white">
      <Navbar />

      <div className="max-w-6xl mx-auto px-6 pt-32 pb-20">
        {/* Page heading */}
        <div className="text-center mb-14">
          <h1 className="font-syne text-5xl font-black mb-3">
            Contact <span className="text-blue-500">Us</span>
          </h1>
          <p className="text-gray-500">We're here to help. Send us a message and we'll respond within 24 hours.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-10">

          {/* Left info */}
          <div className="lg:col-span-2 space-y-6">
            <h2 className="font-syne text-2xl font-black">Get in Touch</h2>
            <p className="text-gray-500 text-sm leading-relaxed">
              Have questions about your resume, templates, or need technical support? Reach out and we'll help you out.
            </p>

            {[
              { icon: "✉️", title: "Email", detail: "support@apnaresumebuilder.com" },
              { icon: "💬", title: "Live Chat", detail: "Available Mon–Fri, 9am–6pm IST" },
              { icon: "📍", title: "Office", detail: "Jaipur, Rajasthan, India" },
            ].map(({ icon, title, detail }) => (
              <div key={title} className="flex items-start gap-4">
                <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-lg shrink-0">
                  {icon}
                </div>
                <div>
                  <p className="font-semibold text-sm">{title}</p>
                  <p className="text-gray-500 text-sm">{detail}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Right form */}
          <div className="lg:col-span-3 bg-[#111] border border-[#222] rounded-2xl p-8">
            {success ? (
              <div className="text-center py-10">
                <div className="text-5xl mb-4">✅</div>
                <h3 className="font-syne text-xl font-black mb-2">Message Sent!</h3>
                <p className="text-gray-500 text-sm mb-6">We'll get back to you within 24 hours.</p>
                <button onClick={resetForm}
                  className="border border-blue-600 text-blue-400 hover:bg-blue-600 hover:text-white px-6 py-2.5 rounded-xl text-sm font-semibold transition-all">
                  Send another message
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider block mb-1">First Name *</label>
                    <input value={form.firstName} onChange={e => set("firstName", e.target.value)}
                      placeholder="Rahul"
                      className="w-full bg-[#1a1a1a] border border-[#333] focus:border-blue-600 text-white px-3 py-2.5 rounded-xl outline-none text-sm transition-colors placeholder:text-gray-700" />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider block mb-1">Last Name</label>
                    <input value={form.lastName} onChange={e => set("lastName", e.target.value)}
                      placeholder="Sharma"
                      className="w-full bg-[#1a1a1a] border border-[#333] focus:border-blue-600 text-white px-3 py-2.5 rounded-xl outline-none text-sm transition-colors placeholder:text-gray-700" />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider block mb-1">Email *</label>
                  <input value={form.email} onChange={e => handleEmail(e.target.value)} type="email"
                    placeholder="rahul@example.com"
                    className={`w-full bg-[#1a1a1a] border text-white px-3 py-2.5 rounded-xl outline-none text-sm transition-colors placeholder:text-gray-700 ${
                      emailValid === false ? "border-red-600" : emailValid === true ? "border-green-600" : "border-[#333] focus:border-blue-600"
                    }`} />
                  {emailValid === false && <p className="text-xs text-red-400 mt-1">Invalid email address</p>}
                  {emailValid === true && <p className="text-xs text-green-400 mt-1">✓ Looks good</p>}
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider block mb-1">Phone</label>
                    <input value={form.phone} onChange={e => set("phone", e.target.value)}
                      placeholder="+91 9876543210"
                      className="w-full bg-[#1a1a1a] border border-[#333] focus:border-blue-600 text-white px-3 py-2.5 rounded-xl outline-none text-sm transition-colors placeholder:text-gray-700" />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider block mb-1">Topic</label>
                    <select value={form.topic} onChange={e => set("topic", e.target.value)}
                      className="w-full bg-[#1a1a1a] border border-[#333] focus:border-blue-600 text-white px-3 py-2.5 rounded-xl outline-none text-sm transition-colors">
                      <option value="">Select topic</option>
                      {Object.keys(TOPIC_KEYWORDS).map(t => <option key={t} value={t}>{t}</option>)}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider block mb-1">Message * (max 500)</label>
                  <textarea value={form.message} onChange={e => handleMessage(e.target.value)}
                    maxLength={500} rows={4} placeholder="How can we help you?"
                    className="w-full bg-[#1a1a1a] border border-[#333] focus:border-blue-600 text-white px-3 py-2.5 rounded-xl outline-none text-sm transition-colors resize-none placeholder:text-gray-700" />
                  <div className="flex justify-between items-center mt-1">
                    <span className="text-xs text-blue-400">{topicSuggestion && !form.topic && (
                      <button type="button" onClick={() => { set("topic", topicSuggestion); setTopicSuggestion(""); }}
                        className="hover:underline">
                        💡 Suggested: {topicSuggestion} — click to apply
                      </button>
                    )}</span>
                    <span className={`text-xs ${charCount > 450 ? "text-red-400" : charCount > 350 ? "text-yellow-400" : "text-gray-600"}`}>
                      {charCount}/500
                    </span>
                  </div>
                  {draftMsg && <p className="text-xs text-green-400 mt-1">{draftMsg}</p>}
                </div>

                {error && (
                  <p className="text-red-400 text-sm bg-red-500/10 border border-red-500/20 rounded-xl py-2 px-3">
                    {error}
                  </p>
                )}

                <button type="submit" disabled={loading}
                  className="w-full bg-blue-600 hover:bg-blue-700 disabled:opacity-60 disabled:cursor-not-allowed text-white py-3.5 rounded-xl font-bold transition-all active:scale-95">
                  {loading ? "Sending…" : "Send Message →"}
                </button>
              </form>
            )}
          </div>
        </div>

        {/* FAQ */}
        <div className="mt-20">
          <h2 className="font-syne text-3xl font-black mb-8 text-center">Frequently Asked Questions</h2>
          <div className="space-y-3 max-w-3xl mx-auto">
            {FAQS.map((faq, i) => (
              <div key={i}
                className="bg-[#111] border border-[#222] hover:border-[#333] rounded-xl overflow-hidden transition-colors cursor-pointer"
                onClick={() => setOpenFaq(openFaq === i ? null : i)}>
                <div className="flex items-center justify-between px-5 py-4">
                  <span className="font-medium text-sm">{faq.q}</span>
                  <span className={`text-blue-500 text-lg transition-transform ${openFaq === i ? "rotate-180" : ""}`}>▼</span>
                </div>
                {openFaq === i && (
                  <div className="px-5 pb-4 text-gray-400 text-sm leading-relaxed border-t border-[#1e1e1e] pt-3">
                    {faq.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
