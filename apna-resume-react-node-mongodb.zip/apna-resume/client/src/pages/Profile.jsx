import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import Navbar from "../components/Navbar";

export default function Profile() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  const initials = user?.displayName
    ? user.displayName.split(" ").map(n => n[0]).join("").slice(0, 2).toUpperCase()
    : user?.email?.[0]?.toUpperCase() || "?";

  const rows = [
    { label: "Email", value: user?.email },
    { label: "Display Name", value: user?.displayName || "—" },
    { label: "Provider", value: user?.provider === "google" ? "Google OAuth" : "Email / Password" },
    { label: "User ID", value: user?._id, mono: true },
    { label: "Member Since", value: user?.createdAt ? new Date(user.createdAt).toLocaleDateString("en-IN", { year: "numeric", month: "long", day: "numeric" }) : "—" },
  ];

  return (
    <div className="min-h-screen bg-black text-white">
      <Navbar />

      {/* BG glow */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-0 left-1/2 w-[600px] h-[400px] -translate-x-1/2 opacity-10 rounded-full"
          style={{ background: "radial-gradient(circle, rgba(37,99,235,0.8) 0%, transparent 70%)" }} />
      </div>

      <main className="relative z-10 flex items-center justify-center min-h-screen px-4 py-8 pt-28">
        <div className="w-full max-w-lg">

          {/* Avatar card */}
          <div className="bg-[#0d0d0d] border border-[#1e1e1e] rounded-3xl overflow-hidden shadow-2xl">
            {/* Top banner */}
            <div className="h-24 bg-gradient-to-r from-blue-900/40 to-blue-600/20 border-b border-[#1e1e1e]" />

            {/* Avatar */}
            <div className="px-8 pb-8">
              <div className="-mt-12 mb-5 flex items-end justify-between">
                <div className="w-20 h-20 rounded-2xl bg-blue-600 flex items-center justify-center text-2xl font-black font-syne border-4 border-[#0d0d0d]">
                  {initials}
                </div>
                <button
                  onClick={handleLogout}
                  className="text-sm px-4 py-2 bg-red-600/10 border border-red-500/30 text-red-400 hover:bg-red-600 hover:text-white rounded-xl transition-all"
                >
                  🚪 Logout
                </button>
              </div>

              <h2 className="font-syne text-2xl font-black mb-1">
                {user?.displayName || "Your Account"}
              </h2>
              <p className="text-gray-500 text-sm mb-6">{user?.email}</p>

              {/* Details */}
              <div className="space-y-3">
                {rows.map(({ label, value, mono }) => (
                  <div key={label} className="flex justify-between items-start gap-4 py-3 border-b border-[#1a1a1a] last:border-0">
                    <span className="text-xs font-semibold text-gray-600 uppercase tracking-wider shrink-0">{label}</span>
                    <span className={`text-sm text-right break-all ${mono ? "font-mono text-gray-500 text-xs" : "text-gray-300"}`}>
                      {value}
                    </span>
                  </div>
                ))}
              </div>

              {/* Actions */}
              <div className="grid grid-cols-2 gap-3 mt-8">
                <Link to="/builder"
                  className="text-center bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-2xl font-bold transition-colors">
                  📄 Build Resume
                </Link>
                <button
                  disabled
                  className="border border-[#2a2a2a] py-3 rounded-2xl font-bold text-gray-600 cursor-not-allowed">
                  ✏️ Edit Profile
                </button>
              </div>
            </div>
          </div>

        </div>
      </main>
    </div>
  );
}
