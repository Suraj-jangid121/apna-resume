import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [dropOpen, setDropOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    setDropOpen(false);
    navigate("/");
  };

  return (
    <header className="fixed top-0 left-0 w-full z-50 bg-black/90 backdrop-blur border-b border-blue-900/50">
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">

        {/* Logo */}
        <Link to="/" className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center font-bold text-sm font-syne">
            ARB
          </div>
          <span className="font-semibold text-lg font-syne hidden sm:block">ApnaResumeBuilder</span>
        </Link>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-gray-400">
          <Link to="/" className="hover:text-blue-400 transition-colors">Home</Link>
          <Link to="/builder" className="hover:text-blue-400 transition-colors">Builder</Link>
          <Link to="/contact" className="hover:text-blue-400 transition-colors">Contact Us</Link>
        </nav>

        {/* Right side */}
        <div className="flex items-center gap-3">
          {user ? (
            <div className="relative">
              <button
                onClick={() => setDropOpen(!dropOpen)}
                className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-xl text-sm font-semibold transition-colors"
              >
                <span className="w-7 h-7 rounded-full bg-white/20 flex items-center justify-center text-xs">
                  {user.displayName?.[0]?.toUpperCase() || user.email[0].toUpperCase()}
                </span>
                <span className="hidden sm:block">Account</span>
              </button>

              {dropOpen && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setDropOpen(false)} />
                  <div className="absolute right-0 mt-2 w-48 bg-[#111] border border-gray-800 rounded-xl shadow-xl z-50 overflow-hidden animate-fade-in">
                    <div className="px-4 py-3 border-b border-gray-800">
                      <p className="text-xs text-gray-500 truncate">{user.email}</p>
                    </div>
                    <Link to="/profile" onClick={() => setDropOpen(false)}
                      className="flex items-center gap-2 px-4 py-3 text-sm hover:bg-gray-800 transition-colors">
                      👤 Your Profile
                    </Link>
                    <Link to="/builder" onClick={() => setDropOpen(false)}
                      className="flex items-center gap-2 px-4 py-3 text-sm hover:bg-gray-800 transition-colors">
                      📄 My Resumes
                    </Link>
                    <button onClick={handleLogout}
                      className="w-full text-left flex items-center gap-2 px-4 py-3 text-sm hover:bg-red-600 transition-colors">
                      🚪 Logout
                    </button>
                  </div>
                </>
              )}
            </div>
          ) : (
            <Link to="/signup"
              className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-xl text-sm font-semibold transition-colors">
              Sign Up
            </Link>
          )}

          {/* Mobile hamburger */}
          <button onClick={() => setMenuOpen(!menuOpen)} className="md:hidden p-2">
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              {menuOpen
                ? <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                : <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />}
            </svg>
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="md:hidden bg-black border-t border-blue-900/40">
          <nav className="flex flex-col px-6 py-4 gap-4 text-gray-400 text-sm">
            <Link to="/" onClick={() => setMenuOpen(false)} className="hover:text-blue-400">Home</Link>
            <Link to="/builder" onClick={() => setMenuOpen(false)} className="hover:text-blue-400">Builder</Link>
            <Link to="/contact" onClick={() => setMenuOpen(false)} className="hover:text-blue-400">Contact Us</Link>
            {user && (
              <>
                <Link to="/profile" onClick={() => setMenuOpen(false)} className="hover:text-blue-400">Profile</Link>
                <button onClick={handleLogout} className="text-left text-red-400 hover:text-red-300">Logout</button>
              </>
            )}
          </nav>
        </div>
      )}
    </header>
  );
}
