import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyBGALyet-KO-n2je5rBgg5mDWfYyIfaRS0",
  authDomain: "apnaresumebuilder.firebaseapp.com",
  projectId: "apnaresumebuilder",
  storageBucket: "apnaresumebuilder.firebasestorage.app",
  messagingSenderId: "478270455880",
  appId: "1:478270455880:web:8a52a65ad267b1277e587d",
};

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
